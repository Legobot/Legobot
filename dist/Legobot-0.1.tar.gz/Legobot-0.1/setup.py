from distutils.core import setup

setup(name='Legobot',
      version='0.1',
      py_modules=['Legobot'],
      )